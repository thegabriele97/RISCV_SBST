# RISC-V TESTS
Tests from https://github.com/riscv/riscv-tests/tree/master/isa

The rather big bunch of folders and its structure were preserved to make
updating the tests less of a hassle. For practical reasons we maintain them
in-tree (mostly amounting to the occasional update).

We currently only run a subset of these tests, namely
* rv32ui
* rv32uc
* rv32um
